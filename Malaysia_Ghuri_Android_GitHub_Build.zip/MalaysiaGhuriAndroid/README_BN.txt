Malaysia Ghuri Like a Local — Android App Project

এই ফোল্ডারটি Android Studio/AndroidIDE দিয়ে APK বানানোর জন্য প্রস্তুত WebView project। ওয়েবসাইটের সম্পূর্ণ HTML app/src/main/assets/index.html ফাইলে রাখা হয়েছে।

APK বানানোর সহজ ধাপ:
1. Android Studio অথবা AndroidIDE-তে এই project folder ওপেন করুন।
2. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (ইন্টারনেট লাগবে; Android Gradle Plugin ডাউনলোড হবে)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. সফল হলে app/build/outputs/apk/debug/app-debug.apk পাওয়া যাবে।
5. APK নিজের Android ফোনে ইনস্টল করতে পারবেন। অজানা উৎস থেকে APK ইনস্টল করার আগে উৎস যাচাই করুন।

Package: com.malaysiaghuri.local
App name: Malaysia Ghuri Like a Local
Version: 1.0
